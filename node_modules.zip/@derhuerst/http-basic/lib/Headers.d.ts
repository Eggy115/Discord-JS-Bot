import { IncomingHttpHeaders } from 'http';
export declare type Headers = IncomingHttpHeaders;
