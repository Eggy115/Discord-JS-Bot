/**
 * Vorbis features
 * @namespace vorbis
 */

module.exports = {
  WebmDemuxer: require('./WebmDemuxer'),
};
